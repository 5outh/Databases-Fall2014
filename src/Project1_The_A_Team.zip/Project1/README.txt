The A Team
Project 1: MovieDB

Benjamin Kovach
Deborah Brown
William Speegle
William Pickard

To compile and run:

```
$ javac *.java
$ java MovieDB
```

Javadocs are stored in the docs directory.