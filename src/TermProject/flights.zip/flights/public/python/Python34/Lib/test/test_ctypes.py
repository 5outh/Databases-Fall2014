import unittest

from ctypes.test import load_tests

if __name__ == "__main__":
    unittest.main()
